#!/usr/bin/env bash
for  i  in $(find . -name INCAR); do 
    cd $(dirname $i)
    rm CHG  CHGCAR  job_sub  PCDAT REPORT  slurm-*.out  WAVECAR  XDATCAR -f
    cd $OLDPWD; 
done 
