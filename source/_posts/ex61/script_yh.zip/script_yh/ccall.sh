#!/usr/bin/env bash 
# This script is used to copy the POSCAR and CONTCAR from server to Desktop
for i in *;  do 
  if [ -e $i/POSCAR ] ; then 
    if [ ! -d ~/Desktop/$i ]; then 
        mkdir ~/Desktop/$i; 
    fi
    cp $i/POSCAR  $i/CONTCAR ~/Desktop/$i 
  fi 
done

