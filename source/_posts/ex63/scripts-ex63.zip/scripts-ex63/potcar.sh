#!/usr/bin/env bash

# Create a GGA_PAW POTCAR file byconcatenation of POTCAR files
# BigBro 2018-04-19 TGN
# To Use it： potcar.sh Cu C H O

# Define local potpaw_GGA pseudopotential path:

path="/THFS/home/iciq-lq/bin/pot"

# Check if older version of POTCAR ispresent

if [ -f POTCAR ] ; then
 mv -f POTCAR old-POTCAR
 echo " ** Warning: old POTCAR file found and renamed to 'old-POTCAR'."
fi

# Main loop - concatenate the appropriatePOTCARs (or archives)

for i in $*; do 
 if test -f $path/$i/POTCAR ; then
  cat $path/$i/POTCAR>> POTCAR
 else
 echo " ** Warning: No suitable POTCAR for element '$i' found!! Skipped thiselement."

 fi
done
